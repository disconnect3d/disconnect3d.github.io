# Compile virtual machine:
gcc vm.c -o server -lgmp

# Create files for the machine
echo 'DrgnS{fake flag here}' > flag
cp example_keys keys

# run local server and solution
./server
python ./solve.py

# correct value of k for key_id=0 is 59614