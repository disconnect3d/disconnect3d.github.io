#!/usr/bin/env python

from Crypto.Util.number import getPrime, inverse

p,q = getPrime(512), getPrime(512)
n = p*q
e = 0x10001
d = inverse(e, (p-1)*(q-1))
k = (d*e - 1) / ((p-1)*(q-1))

print('{:x}'.format(k))
print('{:x}'.format(d)[:128])
print('{:x}'.format((1+k*n)/e)[:128])
print('{:x}'.format((1+k*(n-(2**512)+1))/e)[:128])
