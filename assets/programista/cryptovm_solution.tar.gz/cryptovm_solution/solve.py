#!/usr/bin/env python
# -*- coding: utf-8 -*-

'''
Gros & Tacet
Dragon Teaser 2018, cryptovm
'''

from pwn import *
import argparse


# CONSTANTS
CODESIZE = (1024*1024)
FLAG_SIZE = 1024

MODEWEAK = 0
MODESTRONG = 1

WEAKBYTES = 128
STRONGBYTES = 256

NUM_KEYS = 16
NUM_MEM = 16

MEM_SIZE = 512


# TO BYTE
def to_opcode(s):
    return chr( {
        'OP_FLAG'       : 0,
        'OP_GETPUB'     : 1,
        'OP_SETMODE'    : 2,
        'OP_LOADPRIV'   : 3,
        'OP_LOADPUB'    : 4,
        'OP_RSA'        : 5,
        'OP_SUDO'       : 6,
        'OP_SETMEM'     : 7,
        'OP_ADD'        : 8,
        'OP_SUB'        : 9,
        'OP_MUL'        : 10,
        'OP_DIV'        : 11,
        'OP_MOD'        : 12,
        'OP_POWMOD'     : 13,
        'OP_INVERT'     : 14,
        'OP_PRINT'      : 15,
        'OP_EXIT'       : 100
    }[s] )


# Variables
__var_id = 0
__code_final = ''
__bytes = 0


def get_variable():
    """ Returns high level variable. """
    global __var_id
    ret = __var_id
    __var_id += 1

    assert ret < 16, 'Too many variables ;_;'
    return (lambda : chr(ret))


def get_key(key_id):
    """ Returns high level variable. """

    assert key_id < 16, 'Max 16 keys ;_;'
    return (lambda : chr(key_id))


def get_flag():
    """ If you ARE admin, it will print flag. """

    global __code_final
    __code_final += to_opcode('OP_FLAG')


def get_pub_n(key, var):
    """ Loads key.n to variable. """

    global __code_final
    __code_final += to_opcode('OP_GETPUB') + key() + var()


def set_mode(mode_name):
    """
    Sets mode to given type. 
    WEAK   == currentKey.bytes := WEAKBYTES
    STRONG == currentKey.bytes := STRONGBYTES
    """
    assert mode_name in ['WEAK', 'STRONG'], 'mode_name must be in [WEAK, STRONG]'

    mode_value =  MODEWEAK if mode_name == 'WEAK' else MODESTRONG

    global __bytes
    __bytes = (WEAKBYTES if mode_name == 'WEAK' else STRONGBYTES)

    global __code_final
    __code_final += to_opcode('OP_SETMODE') + chr(mode_value)


def load_prv_key(key):
    """ Loads key with given id to currentKey. """

    global __code_final
    __code_final += to_opcode('OP_LOADPRIV') + key()


def load_pub_key(key):
    """ Loads public part of key with given id to currentKey. """

    global __code_final
    __code_final += to_opcode('OP_LOADPUB') + key()


def rsa(byte_stream, result=None):
    """ Runs RSA with given msg. """
    assert len(byte_stream) == __bytes, 'Incorrect len of msg.'
    assert result is not None, 'result CANNOT be None'

    global __code_final
    __code_final += to_opcode('OP_RSA') + byte_stream + result()


def sudo(key, var):
    """ Changes user status to root. """

    global __code_final
    __code_final += to_opcode('OP_SUDO') + key() + var()


def set_mem(var, byte_stream):
    """ Set variable value to byte_stream. """
    assert len(byte_stream) == MEM_SIZE, 'Stream size != variable size'

    global __code_final
    __code_final += to_opcode('OP_SETMEM') + var() + byte_stream


def add(var1, var2, result=None):
    """ result := vat1 + var2 """
    assert result is not None, 'result CANNOT be None'

    global __code_final
    __code_final += to_opcode('OP_ADD') + var1() + var2() + result()


def sub(var1, var2, result=None):
    """ result := vat1 - var2 """
    assert result is not None, 'result CANNOT be None'

    global __code_final
    __code_final += to_opcode('OP_SUB') + var1() + var2() + result()


def mul(var1, var2, result=None):
    """ result := vat1 * var2 """
    assert result is not None, 'result CANNOT be None'

    global __code_final
    __code_final += to_opcode('OP_MUL') + var1() + var2() + result()


def div(var1, var2, result=None):
    """ result := vat1 // var2 """
    assert result is not None, 'result CANNOT be None'

    global __code_final
    __code_final += to_opcode('OP_DIV') + var1() + var2() + result()


def mod(var1, var2, result=None):
    """ result := vat1 % var2 """
    assert result is  not None, 'result CANNOT be None'

    global __code_final
    __code_final += to_opcode('OP_MOD') + var1() + var2() + result()


def powmod(var1, var2, mod, result=None):
    """ result := pow(vat1, var2, mod) """
    assert result is not None, 'result CANNOT be None'

    global __code_final
    __code_final += to_opcode('OP_POWMOD') + var1() + var2() + mod() + result()


def invert(var, p, result=None):
    """ result := vat1^{-1} mod p """
    assert result is not None, 'result CANNOT be None'

    global __code_final
    __code_final += to_opcode('OP_ADD') + var() + p() + result()


def print_mem(var):
    """ Prints variable memory! """

    global __code_final
    __code_final += to_opcode('OP_PRINT') + var()


def code_is_done():
    """ Adds exit byte. """

    global __code_final
    __code_final += to_opcode('OP_EXIT')


def set_value(var, value):
    """ Set variable to CONSTANT value wit set_mem. """

    stream = ''
    for _ in range(MEM_SIZE):
        stream += chr(value % 256)
        value = value // 256

    set_mem(var, stream)


def get_bytecode():
    """ Create final binary stream. """
    assert len(__code_final) < CODESIZE, 'Too long code. :( {}'.format(len(__code_final))

    log.debug('Your meaning bytecode has', len(__code_final), 'bytes.')
    return __code_final + 'a' * (CODESIZE - len(__code_final) - 1) + '\n'


def get_connect(REMOTE, LOCAL_PATH):
    """ Connect to local/remote server. """
    def hash_cash(con):
        s = con.readline().split()[-3:]
        hashcash = process(s)
        cash = hashcash.recvall().split()[-1]
        hashcash.close()
        con.sendline(cash)

    if REMOTE:
        con = connect('cryptovm.hackable.software', 1337)
        hash_cash(con)
        return con
    else:
        return process(LOCAL_PATH)


def check_keys(remote, local_server):
    """ Check keys' types. """

    global __code_final

    for key_id in range(NUM_KEYS):
        __code_final = ''
        con = get_connect(remote, local_server)

        var_tmp = get_variable()
        key = get_key(key_id)
        sudo(key, var_tmp)
        code_is_done()
        bytecode = get_bytecode()

        con.send(bytecode)
        result = con.recvall()
        con.close()

        if 'error' in result:
            key_type = 'WEAK'
        else:
            key_type = 'STRONG'
        print('Key {} is {}'.format(key_id, key_type))


def program(k_start_value):
    """ Create program """
    s = 'Please give me superuser permissions'
    key_id = 0  # one of strong keys

    # load >whole< module n to currentKey.n
    key = get_key(key_id)
    set_mode('STRONG')
    load_pub_key(key)
    set_mode('WEAK')
    load_prv_key(key)
    set_mode('STRONG')
    # -----

    # set variables, that will not change
    d_offset = get_variable()
    set_value(d_offset, 2**(128*8))

    one_var = get_variable()
    set_value(one_var, 1)

    e_var = get_variable()
    set_value(e_var, 0x10001)

    key_n = get_variable()
    get_pub_n(key, key_n)

    # key_n_aprox = n-(2**1024)+1
    key_n_aprox = get_variable()
    sub(key_n, d_offset, result=key_n_aprox)
    sub(key_n_aprox, one_var, result=key_n_aprox)

    # sig_lsb = s**LSB(d) % n
    sig_lsb = get_variable()
    rsa(s.ljust(256, '\x00'), result=sig_lsb)

    # s_value = numeric value of s
    s_value = get_variable()
    set_value(s_value, int(s[::-1].encode('hex'), 16))
    # -----

    d_msb = get_variable()
    signature = get_variable()
    
    # testing k in range [k_start_value,k_start_value+1900)
    for i in range(1900):
        k = k_start_value + i

        # d_msb = k
        set_value(d_msb, k)

        # d_msb = k*(n-(2**1024)+1)
        mul(key_n_aprox, d_msb, result=d_msb)

        # d_msb = 1 + k*(n-(2**1024)+1)
        add(one_var, d_msb, result=d_msb)

        # d_msb = (1 + k*(n-(2**1024)+1)) / e
        div(d_msb, e_var, result=d_msb)

        # d_msb = MSB((1 + k*(n-(2**1024)+1)) / e) = MSB(d)
        div(d_msb, d_offset, result=d_msb)

        # d_msb = MSB(d)*(2**1024)
        mul(d_offset, d_msb, result=d_msb)

        # signature = s**(MSB(d)*(2**1024)) % n
        powmod(s_value, d_msb, key_n, result=signature)

        # signature = s**(MSB(d)*(2**1024)) * (s**LSB(d)) % n = 
        # s**(MSB(d)*(2**1024) + LSB(d)) % n = s**d % n
        mul(signature, sig_lsb, result=signature)
        
        # send the signature
        sudo(key, signature)
    
    # try to print the flag
    get_flag()
 
    # add exit bytecode
    code_is_done()

    return get_bytecode()


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('-r', '--remote', help='Use remote function rather than local', action='store_true', default=False, dest='REMOTE')
    parser.add_argument('--local_server', default='./server', help='Path to binary with local VM.')
    args = parser.parse_args()

    for k_start_value in range(57001, 0x10001, 1900):
        log.info('Testing k in [{},{}]'.format(k_start_value, k_start_value+1900))
        con = get_connect(args.REMOTE, args.local_server)

        __var_id = 0
        __code_final = ''
        __bytes = 0

        bytecode = program(k_start_value)
        con.send(bytecode)

        print(con.recvall())
        con.close()
