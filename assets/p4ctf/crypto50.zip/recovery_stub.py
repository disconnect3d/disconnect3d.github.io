import codecs
from Crypto.Cipher import AES


def decrypt(ciphertext, key, iv):
    aes = AES.new(key, AES.MODE_CBC, iv)
    return aes.decrypt(ciphertext)


def encrypt(plaintext, key, iv):
    aes = AES.new(key, AES.MODE_CBC, iv)
    return aes.encrypt(plaintext)


def recover_key(message, data):
    raise (NotImplementedError("Implement this!"))


def recover_iv(message, data, real_key):
    raise (NotImplementedError("Implement this!"))


def recovery():
    message = 'Is AES really so hard to break??'
    aes_key = 'pwn{XXX_s3cr3t!}'  # XXX are 3 bytes we lost :(
    iv = "pwn{what_is_XXX}"  # XXX are 3 bytes we lost :(
    with codecs.open("encoded.txt", "r") as input_file:
        data = input_file.read().decode("hex")
        real_key = recover_key(message, data)
        print(real_key)
        real_iv = recover_iv(message, data, real_key)
        print(real_iv)


recovery()
