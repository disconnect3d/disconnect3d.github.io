We encrypted some secret data using AES with custom selected key and IV.
But the script got corrupted. Can you help? We prepared a stub for a solver!