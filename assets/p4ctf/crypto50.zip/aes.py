import codecs

from Crypto.Cipher import AES


def decrypt(ciphertext, key, iv):
    aes = AES.new(key, AES.MODE_CBC, iv)
    return aes.decrypt(ciphertext)


def encrypt(plaintext, key, iv):
    aes = AES.new(key, AES.MODE_CBC, iv)
    return aes.encrypt(plaintext)


def main():
    message = 'Is AES really so hard to break??'
    aes_key = 'pwn{XXX_s3cr3t!}'  # XXX are 3 bytes we lost :(
    iv = "pwn{what_is_XXX}"  # XXX are 3 bytes we lost :(
    with codecs.open("encoded.txt", "w") as output_file:
        encrypted = encrypt(message, aes_key, iv)
        output_file.write(encrypted.encode("hex"))


main()

