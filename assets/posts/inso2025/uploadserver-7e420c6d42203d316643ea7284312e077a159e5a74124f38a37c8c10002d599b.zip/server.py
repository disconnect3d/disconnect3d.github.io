import http.server
import socketserver
import os
import base64
import cgi
from pathlib import Path

USERNAME = os.getenv("USERNAME", "admin")
PASSWORD = os.getenv("PASSWORD", "password")

PORT = 9000
UPLOAD_DIR = "."

os.makedirs(UPLOAD_DIR, exist_ok=True)

class SecureHandler(http.server.SimpleHTTPRequestHandler):
    def authenticate(self):
        auth_header = self.headers.get("Authorization")
        if not auth_header or not auth_header.startswith("Basic "):
            return False

        encoded_credentials = auth_header.split(" ")[1]
        decoded_credentials = base64.b64decode(encoded_credentials).decode("utf-8")
        input_username, input_password = decoded_credentials.split(":", 1)

        return input_username == USERNAME and input_password == PASSWORD

    def do_AUTHHEAD(self):
        self.send_response(401)
        self.send_header("WWW-Authenticate", 'Basic realm="Secure Upload Server"')
        self.send_header("Content-type", "text/html")
        self.end_headers()
        self.wfile.write(b"Unauthorized Access\n")

    def do_GET(self):
        if not self.authenticate():
            self.do_AUTHHEAD()
            return

        requested_path = self.translate_path(self.path)
        if os.path.isfile(requested_path):
            return http.server.SimpleHTTPRequestHandler.do_GET(self)

        return self.list_directory(requested_path)

    def list_directory(self, path):
        self.send_response(403)
        self.end_headers()
        self.wfile.write(b"Directory listing is disabled.")
        return None

    def do_POST(self):
        if not self.authenticate():
            self.do_AUTHHEAD()
            return

        content_type, pdict = cgi.parse_header(self.headers.get('Content-Type'))
        if content_type == 'multipart/form-data':
            pdict['boundary'] = bytes(pdict['boundary'], "utf-8")
            fields = cgi.parse_multipart(self.rfile, pdict)

            for field in fields:
                filename = os.path.basename(field)
                safe_path = Path(UPLOAD_DIR) / filename
                safe_path = safe_path.resolve()

                if not str(safe_path).startswith(str(Path(UPLOAD_DIR).resolve())):
                    self.send_response(400)
                    self.end_headers()
                    self.wfile.write(b"Invalid file path")
                    return

                with open(safe_path, "wb") as f:
                    f.write(fields[field][0])

            self.send_response(200)
            self.end_headers()
            self.wfile.write(b"File uploaded successfully\n")
        else:
            self.send_response(400)
            self.end_headers()
            self.wfile.write(b"Invalid upload request\n")

class ThreadingTCPServer(socketserver.ThreadingMixIn, socketserver.TCPServer):
    daemon_threads = True
    allow_reuse_address = True

with ThreadingTCPServer(("", PORT), SecureHandler) as httpd:
    print(f"Server running on port {PORT} with Basic Auth ({USERNAME}/{PASSWORD})")
    httpd.serve_forever()
